import Zkteco from "zkteco-js";
import { google } from "googleapis";

// Function to clear userId & totalAttendance in sheet
async function clearSheetData(userId) {
  const auth = new google.auth.GoogleAuth({
    credentials: {
      client_email: process.env.GOOGLE_CLIENT_EMAIL,
      private_key: process.env.GOOGLE_PRIVATE_KEY.replace(/\\n/g, "\n"),
    },
    scopes: ["https://www.googleapis.com/auth/spreadsheets"],
  });

  const sheets = google.sheets({ version: "v4", auth });
  const spreadsheetId = "1UvC5d_PJjNdClaDWiOa96O4IO2xGRFQCd72xtK-a2X0";
  const range = "Sheet1!A2:T";

  // Fetch all rows
  const response = await sheets.spreadsheets.values.get({ spreadsheetId, range });
  const rows = response.data.values || [];

  // Find the row where column A (id) matches userId
  const rowIndex = rows.findIndex(row => row[0] === String(userId));
  if (rowIndex === -1) return;

  // Make sure row has at least 20 columns
  while (rows[rowIndex].length < 20) rows[rowIndex].push("");

  // Clear columns S (index 18) & T (index 19)
  rows[rowIndex][18] = "";
  rows[rowIndex][19] = "";

  const updateRange = `Sheet1!A${rowIndex + 2}:T${rowIndex + 2}`;
  await sheets.spreadsheets.values.update({
    spreadsheetId,
    range: updateRange,
    valueInputOption: "USER_ENTERED",
    requestBody: { values: [rows[rowIndex]] },
  });

  console.log(`Cleared userId & totalAttendance for ID ${userId}`);
}

export async function POST(req) {
  const { userId } = await req.json();

  if (!userId) {
    return new Response(
      JSON.stringify({ success: false, message: "userId is required" }),
      { status: 400 }
    );
  }

  const device = new Zkteco("192.168.0.100", 4370, 10000, 4000);

  try {
    await device.createSocket();

    // Fetch current users
    const usersRes = await device.getUsers();
    const users = Array.isArray(usersRes.data) ? usersRes.data : [];

    // Find user by userId
    const deviceUser = users.find(u => u.userId === String(userId));

    if (!deviceUser) {
      await device.disconnect();
      return new Response(
        JSON.stringify({ success: false, message: "User not found on device" }),
        { status: 404 }
      );
    }

    // Delete user using numeric UID
    await device.deleteUser(deviceUser.uid);

    // Wait briefly to persist changes
    await new Promise(res => setTimeout(res, 500));

    // Clear userId & totalAttendance in Google Sheet
    await clearSheetData(userId);

    await device.disconnect();

    return new Response(
      JSON.stringify({
        success: true,
        message: `User ${userId} deleted successfully and sheet updated`,
      }),
      { status: 200 }
    );

  } catch (err) {
    if (device) await device.disconnect().catch(() => {});
    return new Response(
      JSON.stringify({ success: false, message: err.message }),
      { status: 500 }
    );
  }
}
